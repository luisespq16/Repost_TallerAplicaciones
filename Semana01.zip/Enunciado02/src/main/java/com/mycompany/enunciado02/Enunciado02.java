/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.enunciado02;
import Vista.Rubros;
/**
 *
 * @author USER 17
 */
public class Enunciado02 {

    public static void main(String[] args) {
        Rubros productos = new Rubros();
        productos.setVisible(true);
    }
}
