/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.enunciado01;
import Vista.Descuentos;

public class Enunciado01 {

    public static void main(String[] args) {
        Descuentos descuentos = new Descuentos();
        descuentos.setVisible(true);
    }
}
