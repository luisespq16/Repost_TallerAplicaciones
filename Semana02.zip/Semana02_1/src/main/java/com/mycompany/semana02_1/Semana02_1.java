/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana02_1;

import Vista.Tienda;

public class Semana02_1 {

    public static void main(String[] args) {
        Tienda entrada = new Tienda();
        entrada.setVisible(true);
    }
}
