/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana02_2;

import Vista.Empresa;

public class Semana02_2 {

    public static void main(String[] args) {
        Empresa trabajador = new Empresa();
        trabajador.setVisible(true);
    }
}
